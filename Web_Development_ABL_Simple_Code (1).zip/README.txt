WEB DEVELOPMENT ABL - SIMPLE BEGINNER CODE

This project contains 3 small websites built with HTML and CSS:
1. Personal Portfolio
2. College Information
3. Online Learning Platform

HOW TO OPEN:
1. Extract this ZIP file.
2. Open any topic folder.
3. Double-click index.html to open it in your browser.
4. Open index.html and style.css in a text editor to study the code.

CODING STYLE:
- HTML creates the webpage content.
- CSS styles the webpage.
- CSS is written one property per line for easy reading.
- The code uses basic HTML and CSS only.

Note: These are sample front-end websites. Buttons and sample contact details are for demonstration. Real form submission or enrollment needs additional programming.
