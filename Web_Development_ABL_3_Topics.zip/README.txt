WEB DEVELOPMENT ACTIVITY-BASED LEARNING
Three selected case studies: Personal Portfolio, College Information & Admissions, Online Learning Platform

CONTENTS
1. personal-portfolio/index.html and style.css
2. college-admissions/index.html and style.css
3. online-learning/index.html and style.css
4. Analysis_Report.txt

HOW TO RUN
1. Download and extract the ZIP file.
2. Open the folder of any topic.
3. Open index.html in a web browser (Chrome, Firefox, Edge, etc.).
4. To view the code, open index.html and style.css in a text editor such as VS Code or Notepad.
5. Take screenshots of each website in the browser for submission.

NOTE
These are front-end demonstration websites built using HTML and CSS. Forms and buttons are illustrative; they do not submit data or provide real authentication/admissions/enrollment.
